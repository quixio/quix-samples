"""
QuixLake Python SDK

A Python client library for interacting with QuixLake API.
Provides easy-to-use methods for querying, inserting, and managing data.
"""

from .client import QuixLakeClient

__version__ = "0.1.0"
__all__ = ["QuixLakeClient"]